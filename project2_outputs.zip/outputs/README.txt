Project 2 – Outputs

Tidy datasets created from wide tables:
- sales_long.csv: Product–Month–Sales
- scores_long.csv: Student–Subject–Score
- vaccinations_long.csv: Region–Month–Vaccinated

Summaries are also included in CSV format.
